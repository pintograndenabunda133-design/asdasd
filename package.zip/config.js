// Preencha tudo aqui embaixo direto. NÃO suba esse arquivo pra um GitHub/repositório público

// (token e cookie dão acesso total ao bot/conta - se vazar, dá pra outra pessoa controlar).

module.exports = {

  // Discord Developer Portal > sua aplicação > Bot > Reset Token

  DISCORD_TOKEN: 'MTUyOTIyOTk5MTU0MjI2MzgzOA.GR6hth.F57eNAcJeDewZqGvizZwqrwX6HeZjAokzLNApk',

  // Discord Developer Portal > sua aplicação > General Information > Application ID

  CLIENT_ID: '1529229991542263838',

  // ID do seu servidor do Discord (clique direito no servidor com modo dev ativado > Copiar ID)

  // Deixe '' (vazio) se quiser registrar os comandos globalmente (demora até 1h pra aparecer)

  GUILD_ID: '',

  // Cookie .ROBLOSECURITY da sua conta Roblox - só necessário se for usar os comandos /roblox

  // Deixe '' (vazio) se não for usar a parte de Roblox

  ROBLOX_COOKIE: '_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_CAEQAhoEEAQYASIaCgRkdWlkEhI0NzQ4OTk0NjEyNzQxNDUxNDYiGAoFdW5hbWUSD09zdmFsZGlucXVlZGFvNiIRCgN1aWQSCjk0Nzg5ODE3MTkoAw.BI5iZwRT2YmqGYeWVLuqfvGXs8KW9dxXdM1lSow5wIzczjfuE_x5HN_YVELQnWIWWZnhX6-xKh2b0Omz2h5pKJHoGYB1UrrCBJ_-qh9xdkmCmiXVz7mLPkJRaGW2JlCIArXyFO3eoIe81QcTTK7LN0ew9D52_avOaF0bclaz0q1x-i_qVKd8blBNdI59VEJ7qM9_37J_hG3_oXPZjOJEw3j6ML9u-p-XdOZCWv0hMFD3_-fzEPaE6ndxV-h-vkciD_WpL61vMDgaJ2bvJ1nVRfEx7lt9aMcixovNoJy4OFRYHGHrStD26PU0wExKK1is9lrwfMJRkbUDi-YCfArEsmZLKDxaHmf5Vxhdr6Dqxvrz5OvJFuP6_uFx9JoFXICPtRMWTXN71LOBi9QYuj_3ONYpa_e9_E6jO4SEBoBEqrMJ62zfwcjiDedx5v9c64XchxzqSbirP-2pLiiPYOqWAin41_3e18bhmgCjRJXhY5IQt3eqr_nnWRIWKjyFOhkMV48V09CISBruY5Ecyixil23iyaZsiZLxmrZWM1WlOl2NnV0bEdp2DM1uMnsa8A8XygJoRTD_M_tiLBz1arGcaDiFCvMhhwAavwscSA7_gA2k4wZiINRRs4bTKFUztMWCRHugaKQ3O5UNIK3tpo0N9Pn9N4X8HPtnAT3KyeDrwB8UGaKMkE6EXSdCO1USh9ecZKsO2qYBXGaNuxn3DCJxpxl-ox0lgmY3e6oy713r8E_9czCtkKQyd2ShTMfCciE_I-k9-fhSmFaSFZkF_prxfJ5bwpgdQ1iWQRG1RA7SjVSTwURLX6K9NZU9iCByYok6EasA61FPkBHYmgEr01bxTrxFAaqPc1umeoJIfoMW1ARiqabAuiTlW5oCAOA27OaaocCsG0lZrMwRPw4CnO9KsPZQ_ITf1oM1nFIoxfGpIjc.ffEmYzvKBNVp7G7gW6TcP1piGr8',

};